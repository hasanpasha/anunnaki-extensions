from .cinemana import Cinemana

def load_extension():
    return Cinemana()
